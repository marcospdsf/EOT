/* $Id: JuhasNPC.java,v 1.8 2011/03/09 00:48:01 Legolas Exp $ */
/***************************************************************************
 *                   (C) Copyright 2003-2010 - Stendhal                    *
 ***************************************************************************
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
package games.stendhal.server.maps.pol.zakopane.home;

import java.util.Arrays;
import java.util.Map;

import games.stendhal.common.Direction;
import games.stendhal.server.core.config.ZoneConfigurator;
import games.stendhal.server.core.engine.SingletonRepository;
import games.stendhal.server.core.engine.StendhalRPZone;
import games.stendhal.server.entity.npc.ConversationPhrases;
import games.stendhal.server.entity.npc.ConversationStates;
import games.stendhal.server.entity.npc.ShopList;
import games.stendhal.server.entity.npc.SpeakerNPC;
import games.stendhal.server.entity.npc.behaviour.adder.SellerAdder;
import games.stendhal.server.entity.npc.behaviour.impl.SellerBehaviour;

/**
 * Ados MithrilForger (Inside / Level 0).
 *
 * @author kymara
 */
public class JuhasNPC implements ZoneConfigurator {
	private final ShopList shops = SingletonRepository.getShopList();

	/**
	 * Configure a zone.
	 *
	 * @param	zone		The zone to be configured.
	 * @param	attributes	Configuration attributes.
	 */

	@Override
	public void configureZone(final StendhalRPZone zone, final Map<String, String> attributes) {
		buildJuhas(zone);
	}

	private void buildJuhas(final StendhalRPZone zone) {
		final SpeakerNPC juhas = new SpeakerNPC("Juhas") {

			@Override
			protected void createPath() {
				setPath(null);
			}

			@Override
			protected void createDialog() {
				addGreeting("Regards.");
				addJob("I am selling #magic #scrolls. Ask me for a #offer.");
				addHelp("I am selling scrolls, that may save your life or easy your jorney.");

				new SellerAdder().addSeller(this, new SellerBehaviour(shops.get("juhas")));

				add(ConversationStates.ATTENDING, ConversationPhrases.QUEST_MESSAGES,
						null,
						ConversationStates.ATTENDING,
						"I have no jobs for you. The only thing I have is #'magic scrolls' such as , #'ados city scroll', #'fado city scroll', #'kalavan city scroll', #'kirdneh city scroll' and #'touristic ticket'.", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("magic scrolls", "scrolls"),
						null,
						ConversationStates.ATTENDING,
						"I #offer tickets and scrolls that may make you travel faster ,  #'ados city scroll', #'fado city scroll', #'kalavan city scroll', #'kirdneh city scroll' and #'touristic ticket'! Tell: buy <quantity> <scroll name>.", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("zakopane", "zakopane city scroll"),
						null,
						ConversationStates.ATTENDING,
						"These scrolls should take you faster to Zakopane. It is a good way of bailing from the danger.", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("krakowski", "krakowski city scroll"),
						null,
						ConversationStates.ATTENDING,
						"The scroll takes to the royal city of Krakow. f Krakow. It is a very beautiful city wich holds many secrets.", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("ados", "ados city scroll"),
						null,
						ConversationStates.ATTENDING,
						"Ados city scroll, takes immediately to the city of Ados located to the east of here!", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("semos", "home scroll"),
						null,
						ConversationStates.ATTENDING,
						"Home Scrol, this scroll shall take you to the middle city of all Faumoni.", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("nalwor", "nalwor city scroll"),
						null,
						ConversationStates.ATTENDING,
						"Nalwor city scroll, moves to the city of elves called Nalwor, which is located in the forest south of Semos!", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("fado", "faco city scroll"),
						null,
						ConversationStates.ATTENDING,
						"Fado city scroll, takes you to the city of Fado located south-west of Semos!", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("kalavan", "kalavan city scroll"),
						null,
						ConversationStates.ATTENDING,
						"Kalavan city scroll, he takes immediately away to the city of Kalavan located south-west of Semos, outside the city of Fado!", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("kirdneh", "kirdneh city scroll"),
						null,
						ConversationStates.ATTENDING,
						"Kirdneh city scroll, moves to the city of Kirdneh located south-west of Semos, which the Orril River defends!", null);

				add(ConversationStates.ATTENDING,
						Arrays.asList("touristic", "touristic ticket"),
						null,
						ConversationStates.ATTENDING,
						"Touristic ticket, he takes to the desert near the pyramids. Going there, get some water, and remember the hot days and cold nights and dangerous sandstorms!", null);

				addGoodbye("See you and have a good trip.");
				setDirection(Direction.UP);

			}
		};

		juhas.setEntityClass("npcjuhas");
		juhas.setPosition(10, 6);
		juhas.setDirection(Direction.UP);
		juhas.initHP(100);
		zone.add(juhas);
	}
}
